# Sakura Manager Android

هذا مشروع Android بسيط يفتح نسخة Sakura Manager الحالية من الرابط الرسمي، مع دعم JavaScript والتخزين المحلي للويب. بيانات المنتجات والطلبات تظل على قاعدة البيانات المرتبطة بالتطبيق وليست داخل ملف APK.

## بناء APK
1. ارفع محتويات هذا المجلد إلى مستودع GitHub جديد باسم SakuraManagerAndroid.
2. افتح تبويب Actions.
3. اختر Build Sakura Manager APK ثم Run workflow.
4. بعد انتهاء البناء بنجاح، افتح نتيجة التشغيل ونزّل Artifact باسم Sakura-Manager-APK.

الملف الناتج اسمه app-debug.apk.
